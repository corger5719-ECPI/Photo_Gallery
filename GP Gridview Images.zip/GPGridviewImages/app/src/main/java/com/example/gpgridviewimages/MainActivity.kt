package com.example.gpgridviewimages


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.AdapterView
import android.widget.GridView
import android.widget.Toast


// Cora Germany
// July 18, 2026
// GP Thumbnails

class MainActivity : AppCompatActivity() {

    lateinit var imgGrid: GridView
    lateinit var imagesList: List<GridViewModal>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imgGrid = findViewById(R.id.imagesGrid)

        // Add the images and titles to the list
        imagesList = ArrayList<GridViewModal>()
        imagesList = imagesList + GridViewModal (
            getString(R.string.txt_eagle), R.drawable.img_eagle)
        imagesList = imagesList + GridViewModal (
            getString(R.string.txt_elephant), R.drawable.img_elephant)
        imagesList = imagesList + GridViewModal (
            getString(R.string.txt_gorilla), R.drawable.img_gorilla)
        imagesList = imagesList + GridViewModal (
            getString(R.string.txt_panda), R.drawable.img_panda)
        imagesList = imagesList + GridViewModal (
            getString(R.string.txt_panther), R.drawable.img_panther)
        imagesList = imagesList + GridViewModal (
            getString(R.string.txt_polarbear), R.drawable.img_polar)


        val imgAdapter =
            ImgAdapter(this@MainActivity, imagesList)

        imgGrid.adapter = imgAdapter

        imgGrid.onItemClickListener =
            AdapterView.OnItemClickListener { _, _, position, _ ->

                Toast.makeText(
                    applicationContext,
                    "You clicked ${imagesList[position].imageName}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }
}