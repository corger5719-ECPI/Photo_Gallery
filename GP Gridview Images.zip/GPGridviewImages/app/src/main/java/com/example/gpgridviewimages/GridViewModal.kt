package com.example.gpgridviewimages



//Cora Germany
//July 18, 2026
//GP GridView Images - ImageAdapter
data class GridViewModal (
    val imageName: String,
    val imageId: Int
)
